//
//  ImageViewController.swift
//  PhotoViewer
//
//  Created by Soumen Rautray on 06/09/19.
//  Copyright © 2019 Soumen Rautray. All rights reserved.
//

import Cocoa

class ImageViewController: NSViewController, NSTableViewDelegate {
    
    @objc dynamic var imageArray = [Image]()
    @objc dynamic var selectedImageObject : Image = Image()
    
    @IBOutlet weak var imageTableView: NSTableView!
    @IBOutlet weak var favoriteButtonOutlet: NSButton!
    @IBOutlet weak var removeButtonOutlet: NSButton!
    @IBOutlet weak var rotateButtonOutlet: NSButtonCell!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        favoriteButtonOutlet.isHidden = true
        removeButtonStatus()
        rotateButtonStatus()
    }
    
    func tableViewSelectionDidChange(_ notification: Notification) {
        let tableView = notification.object as? NSTableView
        if nonEmptyImageArray() {
            if let selectedImage = tableView?.selectedRow {
                selectedImageObject = self.imageArray[selectedImage] as Image
            }
        }
        removeButtonStatus()
        rotateButtonStatus()
    }

    @IBAction func rotateImageAction(_ sender: Any) {
        let rotatedimage = selectedImageObject.image.imageRotated(by: 90.0)
        selectedImageObject.image = rotatedimage
    }
    
    
    @IBAction func deleteAction(_ sender: Any) {
        if nonEmptyImageArray(){
            self.imageArray.remove(at: self.imageTableView.selectedRow)
            if(self.imageArray.count > 0){
                selectedImageObject = self.imageArray[self.imageArray.count - 1] as Image
                self.imageTableView.selectRowIndexes(NSIndexSet(index: self.imageArray.count - 1) as IndexSet, byExtendingSelection: false)
            } else if (self.imageArray.count == 0){
                resetDetails()
            }
        }
        removeButtonStatus()
        rotateButtonStatus()
    }

    @IBAction func favoriteAction(_ sender: Any) {
        if self.selectedImageObject.isFav == false {
            self.favoriteButtonOutlet.image = NSImage(imageLiteralResourceName: "blackHeart")
            self.selectedImageObject.isFav = true
        }else {
            self.favoriteButtonOutlet.image = NSImage(imageLiteralResourceName: "favorite")
            self.selectedImageObject.isFav = false
        }
    }
    
    @IBAction func addButtonAction(_ sender: Any) {
        if let url = NSOpenPanel().selectUrl {
            addNewImage(from: url)
        } else {
            print("file selection was canceled")
        }
    }
    
    func addNewImage(from url: URL){
        if let selectedImage = NSImage(contentsOf: url) {
            let imageDetails: Image = Image()
            if let imageString = (url.path).components(separatedBy: "/").last?.components(separatedBy: ".") {
                imageDetails.photoName = imageString.first
                imageDetails.path = url.path
                imageDetails.image = selectedImage
                let imageHeight = selectedImage.size.height
                let imageWidth = selectedImage.size.width
                imageDetails.size = "\(imageWidth)x\(imageHeight)"
                imageDetails.format = imageString.last
            }
            if !(imageArray.contains(where: { $0.photoName == imageDetails.photoName })) {
                imageArray.append(imageDetails)
            } else {
                let alert: NSAlert = NSAlert()
                alert.messageText = "Image already exists"
                alert.alertStyle = NSAlert.Style.critical
                alert.addButton(withTitle: "Ok")
                alert.runModal()
            }
            self.imageTableView.selectRowIndexes(NSIndexSet(index: self.imageArray.count - 1) as IndexSet, byExtendingSelection: false)
        }
    }
    
    func nonEmptyImageArray() -> Bool {
        return self.imageArray.count > 0 && self.imageTableView.selectedRow != -1
    }
    
    func removeButtonStatus() -> Void {
        if nonEmptyImageArray() {
            removeButtonOutlet.isEnabled = true
        } else {
            removeButtonOutlet.isEnabled = false
        }
    }
    
    func rotateButtonStatus() -> Void {
        if self.imageArray.count > 0 {
            rotateButtonOutlet.isEnabled = true
        } else {
            rotateButtonOutlet.isEnabled = false
        }
    }
    
    func resetDetails() -> Void {
        selectedImageObject = Image()
    }
 
}
