//
//  TableViewClass.swift
//  PhotoViewer
//
//  Created by Soumen Rautray on 06/09/19.
//  Copyright © 2019 Soumen Rautray. All rights reserved.
//

import Cocoa

class ImageViewController: NSViewController,NSTableViewDelegate {
    
    @objc dynamic var modelArray = [Details]()
    @objc dynamic var selectedImageObject : Details = Details()
    @IBOutlet weak var imageTableView: NSTableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let personObj1: Details = Details()
        personObj1.photoName = "CatImage.jpg"
        personObj1.path = "/library/Desktop/images/CatImage.jpg"
        
        let personObj2: Details = Details()
        personObj2.photoName = "DogImage.jpg"
        personObj2.path = "/library/Desktop/images/DogImage.jpg"

        self.modelArray.append(personObj1)
        self.modelArray.append(personObj2)
        self.selectedImageObject = self.modelArray[0]
    }


        
    
        
    func tableViewSelectionDidChange(_ notification: Notification) {
        print("called")
        let tableView = notification.object as? NSTableView
        if tableView?.selectedRow != nil {
            selectedImageObject = self.modelArray[(tableView?.selectedRow)!] as Details
            print(selectedImageObject.path)
            print(selectedImageObject.photoName)
        }
    }
    
    
    @IBAction func AddButton(_ sender: Any) {
        let openPanel = NSOpenPanel()
        openPanel.allowsMultipleSelection = false
        openPanel.canChooseDirectories = false
        openPanel.canCreateDirectories = false
        openPanel.canChooseFiles = true
        openPanel.begin { (result) -> Void in
            if result.rawValue == NSApplication.ModalResponse.OK.rawValue {
                //Do what you will
                //If there's only one URL, surely 'openPanel.URL'
                //but otherwise a for loop works
            }
        }
    }
}
