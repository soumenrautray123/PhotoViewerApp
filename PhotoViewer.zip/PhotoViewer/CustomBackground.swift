//
//  CustomBackground.swift
//  PhotoViewer
//
//  Created by Soumen Rautray on 11/09/19.
//  Copyright © 2019 Soumen Rautray. All rights reserved.
//

import Cocoa

class CustomBackground : NSView {
    
    override func draw(_ dirtyRect: NSRect) {
        self.wantsLayer = true
        self.layer?.backgroundColor = NSColor(calibratedRed: 212/255, green: 212/255, blue: 212/255, alpha: 0.5).cgColor
    }
    
}
