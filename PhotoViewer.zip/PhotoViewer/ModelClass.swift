//
//  ModelClass.swift
//  PhotoViewer
//
//  Created by Soumen Rautray on 06/09/19.
//  Copyright © 2019 Soumen Rautray. All rights reserved.
//

import Foundation
import Cocoa

class Image: NSObject {
    @objc dynamic var photoName: String?
    @objc dynamic var path: String?
    @objc dynamic var image: NSImage = NSImage()
    @objc dynamic var size: String?
    @objc dynamic var format: String?
    @objc dynamic var isFav: Bool = false
}
