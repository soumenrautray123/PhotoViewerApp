//
//  Extensions.swift
//  PhotoViewer
//
//  Created by Soumen Rautray on 16/09/19.
//  Copyright © 2019 Soumen Rautray. All rights reserved.
//

import Foundation
import Cocoa
import Quartz

public extension NSImage {
    
    func imageRotated(by degrees: CGFloat) -> NSImage {
        let imageRotator = IKImageView()
        var imageRect = CGRect(x: 0, y: 0, width: self.size.width, height: self.size.height)
        let cgImage = self.cgImage(forProposedRect: &imageRect, context: nil, hints: nil)
        imageRotator.setImage(cgImage, imageProperties: [:])
        imageRotator.rotationAngle = CGFloat(-(degrees / 180) * CGFloat.pi)
        let rotatedCGImage = imageRotator.image().takeUnretainedValue()
        return NSImage(cgImage: rotatedCGImage, size: NSSize.zero)
    }
}

public extension NSOpenPanel {
    var selectUrl: URL? {
        title = "Select Image"
        allowsMultipleSelection = false
        canChooseDirectories = false
        canChooseFiles = true
        canCreateDirectories = false
        allowedFileTypes = ["jpg","jpeg","png","pdf","pct", "bmp", "tiff"]
        return runModal() == .OK ? urls.first : nil
    }
}
